const jwt = require('jsonwebtoken');
const db  = require('../utils/db');

// ── Verifica JWT para utilizadores normais ────────────────────────
async function requireAuth(req, res, next) {
    const token = req.headers['authorization']?.split(' ')[1];
    if (!token) return res.status(401).json({ ok: false, msg: 'Token em falta' });

    try {
        const payload = jwt.verify(token, process.env.JWT_SECRET);
        // Check user still exists and isn't banned
        const [rows] = await db.query(
            'SELECT id, username, role, banned FROM users WHERE id = ?',
            [payload.userId]
        );
        if (!rows.length || rows[0].banned) {
            return res.status(401).json({ ok: false, msg: 'Conta banida ou não encontrada' });
        }
        req.user = rows[0];
        next();
    } catch (e) {
        return res.status(401).json({ ok: false, msg: 'Token inválido ou expirado' });
    }
}

// ── Verifica se é admin ───────────────────────────────────────────
function requireAdmin(req, res, next) {
    if (req.user?.role !== 'admin') {
        return res.status(403).json({ ok: false, msg: 'Acesso negado' });
    }
    next();
}

// ── Log helper ────────────────────────────────────────────────────
async function logAction(userId, action, details, ip) {
    try {
        await db.query(
            'INSERT INTO logs (user_id, action, details, ip_address) VALUES (?,?,?,?)',
            [userId || null, action, details || null, ip || null]
        );
    } catch (e) { /* silent */ }
}

module.exports = { requireAuth, requireAdmin, logAction };
